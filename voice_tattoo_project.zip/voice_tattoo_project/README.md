# 声波纹身小程序 + Flask 后端

## 📌 项目介绍
本项目实现：
1. **微信小程序** 上传用户音频
2. **Flask 后端** 处理音频，生成 5 种风格的声波图案
3. **返回纹身设计图** 给小程序，用户可预览

## 📌 后端运行方法
```bash
pip install -r requirements.txt
python server.py
```

## 📌 前端运行方法
1. 使用 **微信开发者工具** 打开 `frontend/`
2. 确保 `app.json` 配置正确
3. 运行小程序

## 📌 项目目录介绍
1. backend后端项目代码。
2. output存放所生成的图片
3. upload存放用户所上传的音频
4. server.py负责前后端交互接收请求，
调用utils.py中的函数处理音频并返回生成图案
5. utils.py包含所有音频处理，图像输出等辅助功能